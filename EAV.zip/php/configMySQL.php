<?php 
date_default_timezone_set('America/Mexico_City');

$pageLimit = 20;

$mysql_config = array(
  'host' => '127.0.0.1',
  'db' => 'eav',
  'user' => 'root',
  'pass' => ''
);
?>